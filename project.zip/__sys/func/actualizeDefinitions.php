<?php


	// Changes champion IDs and map IDs into valid recent names on request.
	function actualizeDefinitions($matches) {
		global $_sys, $maps;

		// Get dictionaries
		require_once(__DIR__."/../loader.php");
		require_once("$_sys/res/constant_map_definitions.php");
		$champDefinitions = getCacheData("SELECT * FROM champions");


		if     (!$champDefinitions || count($champDefinitions) < 64) return reportError("Very weird response from local database!", __FILE__, __LINE__);
		elseif (!$maps || count($maps) < 2)                          return reportError("Very weird response from local file!", __FILE__, __LINE__);

		$i = 0;

		foreach ($matches as $match) {
			$i++;

			$dictChampId = array_search($match["champion"]["id"], array_column($champDefinitions, "id"));

			if ($champDefinitions[$dictChampId]["name"]) {
				$matches[$i]["champion"]["name"] = $champDefinitions[$dictChampId]["name"];
				$matches[$i]["champion"]["title"] = $champDefinitions[$dictChampId]["title"];
				$matches[$i]["champion"]["smallimage"] = $champDefinitions[$dictChampId]["icon"];
				$matches[$i]["champion"]["bigimage"] = $champDefinitions[$dictChampId]["image"];
			}
			else {
				$matches[$i]["champion"]["name"] = "Unknown (ID: {$match["champion"]["id"]})";
				$matches[$i]["champion"]["title"] = "Requires definition update (every hour or so)";
				$matches[$i]["champion"]["smallimage"] = "ff56caecea347e5162fddbc9586b094a";
				$matches[$i]["champion"]["bigimage"] = "https://static.vecteezy.com/system/resources/previews/000/092/926/original/question-mark-background-in-vector.jpg";
			}

			if (!($matches[$i]["map"]["name"] = $maps[$match["map"]["id"]])) $matches[$i]["map"]["name"] = "Unknown (ID: {$match["map"]["id"]})";
		}
		return $matches;
	}

?>
