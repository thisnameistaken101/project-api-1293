<?php

	// Uploads data to database.
	// Returns true if succeeded.
	// Returns false if failed.


	function setCacheData($req) {
		global $dbconn;

		$res = $dbconn->query($req);

		return ($res === true) ? true : false;
	}

?>
