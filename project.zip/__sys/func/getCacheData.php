<?php

	// Gets data from database. Returns false is result returns
	// false or when amount of rows is 0. False == False basically.


	require_once(__DIR__."/../loader.php");
	require_once("$_sys/res/dbconn.php");


	function getCacheData($req) {
    	global $dbconn;

		$result = $dbconn->query($req);

		if ($result) {
			if ($result->num_rows == 0) return false;
			else return $result->fetch_all(MYSQLI_ASSOC);
		}
		else return false;
	}

?>
