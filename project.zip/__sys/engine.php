<?php

	require_once("loader.php");
	require_once("$_sys/common.php");

	if (empty($_GET["name"]) || strlen($_GET["name"]) > 16) { redirect("index.php?err=true"); }
	else { $name = $_GET["name"]; }

	require_once("$_sys/res/apikey.php");
	require_once("$_sys/res/dbconn.php");
	require_once("$_sys/res/constant_map_definitions.php");

	require_once("$_sys/func/isNameValid.php");
	require_once("$_sys/func/getCacheData.php");
	require_once("$_sys/func/getRemoteData.php");
	require_once("$_sys/func/actualizeDefinitions.php");



	// This entire function decides what is returned.
	// If played has any matches or even exists.
	function Engine($name) {
		global $_sys, $maps, $dbconn;

		$isNewEntry = true;				// Defines whether INSERT or UPDATE data
		$matchIndex = 0;				// Used for future looping

		if (!isNameValid($name)) {
			$encodedName = rawurlencode($name);


			// Get basic data from API (incl. ID and last-updated timestamp). Return false if user doesn't exist
			$remoteBasicData = getRemoteData("https://euw.api.pvp.net/api/lol/euw/v1.4/summoner/by-name/$encodedName?api_key=".getAPIKey());
			$remoteBasicData = array_values($remoteBasicData)[0];
			if (!$remoteBasicData || count($remoteBasicData) != 5) return reportError("Unknown response!", __FILE__, __LINE__);

			$playerData["id"]       = (int)$remoteBasicData["id"];
			$playerData["revision"] = (int)$remoteBasicData["revisionDate"];
			$level                  = (int)$remoteBasicData["summonerLevel"];


			// Find out about users rank and report it back
			$query = "https://euw.api.pvp.net/api/lol/euw/v2.5/league/by-summoner/{$playerData["id"]}?api_key=".getAPIKey();
			if ($remoteRankData = getRemoteData($query)) {
				$rank = @ucfirst(@strtolower(@$remoteRankData[$playerData["id"]][0]["tier"]));

				$x = @array_search($playerData["id"], array_column($remoteRankData[$playerData["id"]][0]["entries"], "playerOrTeamId"));
				$personalLeague = $remoteRankData[$playerData["id"]][0]["entries"][$x];

				$playerData["lp"] = $personalLeague["leaguePoints"];

				if (in_array($rank, array("Challenger", "Master"))) $playerData["rank"] = $rank;
				elseif ($rank == "")								$playerData["rank"]	= "Unranked ($level)";
				else											    $playerData["rank"] = $rank . " {$personalLeague["division"]}";
			}
			else return reportError("Users exists, but doesn't?", __FILE__, __LINE__);


			// Compare database cache and API last-updated. If equally new, prepare and return data from database, otherwise update and return
			if ($cacheBasicData = getCacheData("SELECT id, revision FROM players WHERE id={$playerData["id"]}")) {
				$isNewEntry = false;

				$cacheBasicData = array_values($cacheBasicData)[0];

				if ($cacheBasicData["revision"] == $playerData["revision"]) {
					if ($cacheData = getCacheData("SELECT matches, stats FROM players WHERE id={$playerData["id"]}")) {
						$playerData["matches"] = base64_decode($cacheData[0]["matches"]);
						$playerData["matches"] = json_decode($playerData["matches"], true);
						$playerData["matches"] = actualizeDefinitions($playerData["matches"]);

						$playerData["stats"] = base64_decode($cacheData[0]["stats"]);
						$playerData["stats"] = json_decode($playerData["stats"], true);
						return $playerData;
					}
					else return reportError("Couldn't connect to database to get data!", __FILE__, __LINE__);
				}
			}


			require_once("$_sys/func/setCacheData.php");


			// Extract usable data from API regarding each and every match, and stuff it into array.
			$remoteMatchList = getRemoteData("https://euw.api.pvp.net/api/lol/euw/v2.2/matchlist/by-summoner/{$playerData["id"]}?beginIndex=0&endIndex=37&api_key=".getAPIKey());

			if ($remoteMatchList) {
				foreach ($remoteMatchList["matches"] as $match) {
					$matchIndex++;

					$playerData["matches"][$matchIndex]["champion"]["id"] = $match["champion"];

					$remoteMatchData = getRemoteData("https://euw.api.pvp.net/api/lol/euw/v2.2/match/{$match["matchId"]}?api_key=".getAPIKey());

					foreach($remoteMatchData["participantIdentities"] as $item) {
						if ($item["player"]["summonerId"] == $playerData["id"]) $myPartId = $item["participantId"];
					}
					$y = array_search($myPartId, array_column($remoteMatchData["participants"], "participantId"));
					$isWinner = $remoteMatchData["participants"][$y]["stats"]["winner"];

					$playerData["matches"][$matchIndex]["map"]["id"] = (int)$remoteMatchData["mapId"];
					$playerData["matches"][$matchIndex]["timestamp"] = intval($remoteMatchData["matchCreation"] / 1000);
					$playerData["matches"][$matchIndex]["stats"]["kills"] = (int)$remoteMatchData["participants"][$y]["stats"]["kills"];
					$playerData["matches"][$matchIndex]["stats"]["deaths"] = (int)$remoteMatchData["participants"][$y]["stats"]["deaths"];
					$playerData["matches"][$matchIndex]["stats"]["assists"] = (int)$remoteMatchData["participants"][$y]["stats"]["assists"];
					$playerData["matches"][$matchIndex]["stats"]["creepscore"] = (int)$remoteMatchData["participants"][$y]["stats"]["minionsKilled"];

					$playerData["stats"]["totalKills"]   += $remoteMatchData["participants"][$y]["stats"]["kills"];
					$playerData["stats"]["totalDeaths"]  += $remoteMatchData["participants"][$y]["stats"]["deaths"];
					$playerData["stats"]["totalAssists"] += $remoteMatchData["participants"][$y]["stats"]["assists"];
					$playerData["stats"]["totalCreeps"]  += $remoteMatchData["participants"][$y]["stats"]["minionsKilled"];

					if ($isWinner) {
						$playerData["matches"][$matchIndex]["result"]["text"] = "Victory";
						$playerData["matches"][$matchIndex]["result"]["color"] = "27AE60";

						$playerData["stats"]["victory"] += 1;
					}
					else {
						$playerData["matches"][$matchIndex]["result"]["text"] = "Defeat";
						$playerData["matches"][$matchIndex]["result"]["color"] = "E74C3C";
					}
				}
			}
			else $playerData["matches"] = false;


			// If entry exists UPDATE it, if it doesn't, INSERT (create) it
			if ($isNewEntry) {
				setCacheData("INSERT INTO players (id, revision, stats, matches) VALUES (
												  {$playerData["id"]},
												  {$playerData["revision"]},
											 	  '" .base64_encode(json_encode($playerData["stats"])). "',
												  '" .base64_encode(json_encode($playerData["matches"])). "'
										   )");
			}
			else {
				setCacheData("UPDATE players SET
								revision='{$playerData["revision"]}',
								stats='" .base64_encode(json_encode($playerData["stats"])). "',
								matches='" .base64_encode(json_encode($playerData["matches"])). "'
							 WHERE
							 	id={$playerData["id"]}
							");
			}

			if ($playerData["matches"]) $playerData["matches"] = actualizeDefinitions($playerData["matches"]);

			return $playerData;
		}
		else return reportError("The name provided didn't pass through regex requirements!", __FILE__, __LINE__);
	}


	$data = Engine($name);
	$dbconn->close();


	if (!$data) redirect("index.php?err=true");


	$wonMatches   = $data["stats"]["victory"];
	$totalMatches = count($data["matches"]);

	$showKDA     = true;
	$showWinrate = true;

	$rank = $data["rank"];
	$totalKills   = $data["stats"]["totalKills"];
	$totalDeaths  = $data["stats"]["totalDeaths"];
	$totalAssists = $data["stats"]["totalAssists"];
	$totalCreeps  = $data["stats"]["totalCreeps"];

	if ($wonMatches === null || $totalMatches == 0) {
		$showWinrate = false;		// If user hasn't played recent matches, it prevents "NAN% winratio".
	}

	if ($totalKills === null || $totalDeaths === null || $totalAssists == null) {
		$showKDA = false;			// If user hasn't played recent matches, it prevents "// cs".
	}

	$headerImage = ($data["matches"][1]["champion"]["bigimage"] == true) ? "background-image: url('".$data["matches"][1]["champion"]["bigimage"]."');" : "";

	echo "<script>var getPlayerName = \"{$_GET["name"]}\";</script>";

?>
