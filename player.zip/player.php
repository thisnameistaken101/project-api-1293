<?php

	require_once(__DIR__."/__sys/loader.php");
	require_once("$_sys/engine.php");

?>

<html>
	<head>
		<?php header("Page: player.php"); ?>
		<?php require_once("$_sys/head.php"); ?>
		<script src="js/jquery.timeago.js"></script>
		<script src="js/player.js"></script>
		<link rel="stylesheet" href="css/general.css" media="all" />
		<link rel="stylesheet" href="css/player.css" media="all" />
	</head>
	<body>
		<div class="wrapper">
			<div class="header" style="background-image: url('<?php echo $data["matches"][1]["champion"]["bigimage"]; ?>');">
				<a class="backBtn" href="index.php">&nbsp;</a><br />
				<div class="textwrap">
					<span class="rank"><?php echo $rank; ?></span><br />
					<?php if ($showWinrate) echo "<span class=\"winrate\">".round($wonMatches / $totalMatches * 100, 0)."% winratio</span><br />"; ?>
					<?php if ($showKDA)     echo "<span class=\"stats\">$totalKills/$totalDeaths/$totalAssists {$totalCreeps}cs</span>"; ?>
				</div>
			</div>
			<div class="matchesData">
				<?php

					if ($data["matches"]) {
							echo "
								<table>
									<thead>
										<tr>
											<th>Result</th>
											<th>Champion</th>
											<th>Statistics</th>
											<th>Map</th>
											<th>When Played</th>
										</tr>
									</thead>
									<tbody>
								";
								foreach ($data["matches"] as $match) {
									$timestampScript = date("Y-m-d\TH:i:s\Z", ($match["timestamp"]));
									$timestampReadable = date("d-m-Y H:i", ($match["timestamp"]));
									$resultColor = $match["result"]["color"];
									$resultText = $match["result"]["text"];
									$champName = $match["champion"]["name"];
									$champIcon = $match["champion"]["smallimage"];
									$champSplash = $match["champion"]["bigimage"];
									$champTitle = $match["champion"]["title"];
									$kills = $match["stats"]["kills"];
									$deaths = $match["stats"]["deaths"];
									$assists = $match["stats"]["assists"];
									$creeps = $match["stats"]["creepscore"];
									$map = $match["map"]["name"];

									echo "
										<tr>
											<td class=\"resultSlot\" style=\"color: #$resultColor\">$resultText</td>
											<td class=\"championSlot\">
												<img src=\"$champIcon\" />
												<a href=\"$champSplash\" target=\"__blank\" title=\"$champTitle\">$champName</a>
											</td>
											<td>$kills/$deaths/$assists – {$creeps}cs</td>
											<td class=\"mapSlot\">$map</td>
											<td><abbr class=\"timeSlot\" title=\"$timestampScript\">$timestampReadable</abbr></td>
										</tr>
									";
								}
							echo "
									</tbody>
								</table>
							";
						}
						else {
							echo "
								<div class=\"nomatches\">
									There doesn't seem to be any recent match of this player.
								</div>
							";
						}
				?>
			</div>
		</div>
	</body>
</html>
